# notebook-backend/app.py

from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS, cross_origin
import os
from werkzeug.utils import secure_filename
import json
import time
from datetime import datetime
from dotenv import load_dotenv
import re
import subprocess
from pathlib import Path
import threading
import tempfile
import shutil
import sys
from collections import deque  # For filtering orgchart

# DeepSeek 相关的导入
from openai import OpenAI
from openai import APIConnectionError, RateLimitError, APIStatusError

# 用于文档内容提取和生成
import docx
from io import BytesIO
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter

# 导入中文分词库 jieba # 注意：如果jieba未安装，RAG可能退化到简单匹配


# 导入业务逻辑模块
from llm_interface import DeepSeekLLM
from data_manager import TemplateMethodManager
from text_summarizer import TextSummarizer
from question_rewriter import QuestionRewriter
import search_similar  # <--- 导入 search_similar 模块

# 加载 .env 文件中的环境变量
load_dotenv()

# --- Flask 应用配置 ---
app = Flask(__name__)

# --- CRITICAL FIX: CORS Configuration ---
CORS(app, resources={
    r"/*": {"origins": "http://localhost:3000", "methods": ["GET", "HEAD", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
            "allow_headers": ["Content-Type", "x-requested-with", "Authorization"], "supports_credentials": True}})

print("DEBUG: CORS configured globally for all routes in app.py")

# --- 文件存储配置 ---
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
    print(f"Created uploads directory at: {os.path.abspath(UPLOAD_FOLDER)}")

# --- API Keys 配置 ---
deepseek_api_key = "sk-945bab02da964bcdaca673485c32dfff"
if not deepseek_api_key:
    print("WARNING: DEEPSEEK_API_KEY not found in .env file or environment variables.")
    print("AI model calls might fail. Please add DEEPSEEK_API_KEY=your_key_here to your .env file.")

dashscope_api_key = "sk-31510d140d0c4af28612ce447f28943e"
if not dashscope_api_key:
    print("WARNING: DASHSCOPE_API_KEY not found in .env file or environment variables.")
    print("External processing scripts (OCR, Catalog, Segmentation) might fail.")

DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
openai_client_for_chat_rag = OpenAI(
    api_key=deepseek_api_key,
    base_url=DEEPSEEK_BASE_URL
)
DEFAULT_DEEPSEEK_MODEL = "deepseek-chat"

# --- 新功能模块初始化 ---
llm_client_for_tasks = DeepSeekLLM(api_key=deepseek_api_key, model=DEFAULT_DEEPSEEK_MODEL, base_url=DEEPSEEK_BASE_URL)
TEMPLATES_FILE = "templates_methods.json"  # 模板文件仍然是全局的，因为可能跨项目复用
template_manager = TemplateMethodManager(file_path=TEMPLATES_FILE)  # 答题方法/模板管理器

text_summarizer_module = TextSummarizer(llm_client=llm_client_for_tasks)
question_rewriter_module = QuestionRewriter(llm_client=llm_client_for_tasks, template_manager=template_manager)

# --- 项目数据持久化 ---
# 主数据结构将是 projects 列表，每个项目包含其自己的 files_metadata, chat_history, chat_messages
projects_data = []

PROJECTS_DATA_FILE = 'projects_data.json'  # 新的持久化文件

# --- 思维导图演示文件路径 (hardcoded for demo) ---
DEMO_FULL_ORGCHART_PATH = Path("D:/college/EduMind/textbook_orgchart.json").resolve()
DEMO_FILTERED_ORGCHART_PATH = Path("D:/college/EduMind/questions_filtered_textbook_orgchart.json").resolve()


def load_projects_data():
    global projects_data
    if os.path.exists(PROJECTS_DATA_FILE):
        with open(PROJECTS_DATA_FILE, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
                projects_data = data.get('projects', [])
                print(f"Projects data loaded from {PROJECTS_DATA_FILE}")
            except json.JSONDecodeError as e:
                print(f"Error decoding {PROJECTS_DATA_FILE}: {e}. Starting with empty projects data.")
                # 备份损坏的文件
                if os.path.exists(PROJECTS_DATA_FILE):
                    os.rename(PROJECTS_DATA_FILE, f"{PROJECTS_DATA_FILE}.bak_{int(time.time())}")
    else:
        print(f"No {PROJECTS_DATA_FILE} found, starting with empty projects data.")


def save_projects_data():
    data = {
        'projects': projects_data
    }
    with open(PROJECTS_DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    print(f"Projects data saved to {PROJECTS_DATA_FILE}")


# 辅助函数：获取特定项目的数据
def get_project_by_id(project_id):
    return next((p for p in projects_data if p['id'] == project_id), None)


# --- 文件内容分块函数 (for RAG) ---
def chunktext(text, chunk_size=800, chunk_overlap=100):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        is_separator_regex=False
    )
    raw_chunks = text_splitter.split_text(text)
    return [c.strip() for c in raw_chunks if c.strip()]


# --- 文件内容提取函数 (for RAG and Template Extraction from full text) ---
def extract_text_from_file(filepath, file_type):
    full_text = ""
    try:
        if file_type == 'docx':
            doc = docx.Document(filepath)
            for paragraph in doc.paragraphs:
                full_text += paragraph.text + "\n"
            print(f"Extracted {len(full_text)} characters from DOCX.")
        elif file_type == 'pdf':
            reader = PdfReader(filepath)
            for page_num in range(len(reader.pages)):
                page = reader.pages[page_num]
                page_text = page.extract_text()
                if page_text:
                    full_text += page_text + "\n"
            print(f"Extracted {len(full_text)} characters from PDF using PyPDF2.")
        elif file_type in ['txt', 'md', 'json', 'log', 'py', 'js', 'css', 'html', 'xml']:
            with open(filepath, 'r', encoding='utf-8') as f:
                full_text = f.read()
            print(f"Read {len(full_text)} characters from plain text file.")
        else:
            print(f"Warning: File type {file_type} not supported for text extraction.")
            return [], f"无法提取类型为 {file_type} 的文件内容。"

    except Exception as e:
        print(f"Error extracting text from {filepath} ({file_type}): {e}")
        return [], f"提取文件内容时发生错误: {str(e)}"

    chunks = chunktext(full_text)

    structured_chunks = []
    for i, chunk_text in enumerate(chunks):
        if chunk_text.strip():
            structured_chunks.append({
                "id": f"chunk_{i + 1}",
                "text": chunk_text,
                "original_full_text": full_text
            })
    return structured_chunks, ""


# --- 辅助函数：将嵌套目录转为平面列表（用于过滤前处理） ---
def flatten_catalog_recursive(nodes: list, parent_id: str = None) -> list:
    """
    Recursively flattens a nested chapter structure into a flat list of nodes,
    adding 'pid' and 'generated_path_id' to each node if not already present.
    """
    flat_list = []
    if not isinstance(nodes, list):
        return flat_list

    for i, node in enumerate(nodes):
        current_node_id = node.get('generated_path_id')
        if not current_node_id:
            current_node_id = f"{parent_id}.{i + 1}" if parent_id else str(i + 1)
            node['generated_path_id'] = current_node_id  # Add to original node for subsequent recursive calls

        node_copy = node.copy()
        node_copy['pid'] = parent_id

        # Remove children from the flat copy to avoid infinite recursion/deep nesting in flat list
        children_nodes = node_copy.pop('children', [])

        flat_list.append(node_copy)

        if children_nodes and isinstance(children_nodes, list):
            flat_list.extend(flatten_catalog_recursive(children_nodes, current_node_id))
    return flat_list


# --- 辅助函数：过滤目录结构（从 get_questions_orgchart.py 借鉴） ---
def filter_orgchart_nodes(
        all_nodes: list,  # Flat list of all nodes (e.g., from catalog_with_segments.json)
        target_kp_names: set  # Set of knowledge point names to match (exact match for KP text)
) -> list:
    """
    Filters the orgchart based on target_kp_names.
    Keeps nodes whose 'name' or any of their 'knowledge_points' text matches a target KP.
    Also keeps their ancestors (up to root) and their descendants.
    The input and output are flat lists of node objects.
    """
    if not all_nodes:
        print("WARNING: Input orgchart nodes are empty. Returning empty list.")
        return []

    node_map = {node['generated_path_id']: node for node in all_nodes if 'generated_path_id' in node}

    # Rebuild parent-child relationships from flat list
    parent_to_children_map = {}
    child_to_parent_map = {}  # For efficient ancestor lookup
    root_node_ids = set()

    for node_id, node_data in node_map.items():
        if node_data.get('pid') is None or str(node_data.get('pid')).lower() == "null" or node_data.get('pid') == "":
            root_node_ids.add(node_id)
        else:
            pid = node_data['pid']
            if pid not in parent_to_children_map:
                parent_to_children_map[pid] = []
            parent_to_children_map[pid].append(node_id)
            child_to_parent_map[node_id] = pid

    kept_node_ids = set()

    # 1. Initially keep all root nodes (if any)
    kept_node_ids.update(root_node_ids)

    # 2. Identify initial nodes to keep based on target_kp_names matching node['name'] or node['knowledge_points']
    initially_matched_ids = set()
    for node_id, node_data in node_map.items():
        # Match by node name
        if node_data.get('name') and node_data['name'] in target_kp_names:
            initially_matched_ids.add(node_id)
            kept_node_ids.add(node_id)

        # Match by knowledge points within the node
        if node_data.get('knowledge_points') and isinstance(node_data['knowledge_points'], list):
            for kp_text in node_data['knowledge_points']:
                if kp_text in target_kp_names:  # Direct match of KP content
                    initially_matched_ids.add(node_id)
                    kept_node_ids.add(node_id)
                    break  # Found a match for this node, no need to check other KPs in it

    print(f"DEBUG Filter: Initially matched {len(initially_matched_ids)} nodes by KP name/content.")

    # 3. Add all descendants of these initially matched nodes
    #    Use BFS for descendants
    descendant_q = deque(list(initially_matched_ids))
    processed_for_descendants = set(initially_matched_ids)  # To avoid cycles in case of complex graphs

    while descendant_q:
        current_id_for_descendants = descendant_q.popleft()

        if current_id_for_descendants in parent_to_children_map:
            for child_id in parent_to_children_map[current_id_for_descendants]:
                if child_id not in processed_for_descendants:  # If child not already processed
                    kept_node_ids.add(child_id)  # Keep the child
                    descendant_q.append(child_id)  # Add child to queue to process its descendants
                    processed_for_descendants.add(child_id)

    print(f"DEBUG Filter: After adding descendants, {len(kept_node_ids)} nodes are marked to be kept.")

    # 4. Add all ancestors of all currently kept nodes up to the root(s)
    #    Iterate over a copy of kept_node_ids as we might add more during iteration.
    nodes_to_trace_ancestors_for = list(kept_node_ids)  # Convert to list to allow appending
    processed_for_ancestors = set(kept_node_ids)  # To avoid re-processing same ancestor paths

    for node_id_to_trace_up in nodes_to_trace_ancestors_for:  # Iterating over a list that might grow
        current_trace_id = node_id_to_trace_up
        while current_trace_id in child_to_parent_map:  # While current_trace_id has a parent
            parent_id = child_to_parent_map[current_trace_id]
            if parent_id not in processed_for_ancestors:  # If parent not already processed/kept
                kept_node_ids.add(parent_id)
                nodes_to_trace_ancestors_for.append(parent_id)  # Add to list to ensure its ancestors are also traced
                processed_for_ancestors.add(parent_id)
                current_trace_id = parent_id  # Move up
            else:
                break  # Already kept this parent, stop tracing up this path

    print(f"DEBUG Filter: After adding ancestors, {len(kept_node_ids)} nodes are marked to be kept.")

    # 5. Construct the final list of node objects from the kept_node_ids
    final_filtered_node_list = [node_map[id_] for id_ in kept_node_ids if id_ in node_map]
    print(f"DEBUG Filter: Final filtered orgchart will contain {len(final_filtered_node_list)} nodes.")

    return final_filtered_node_list


# --- 辅助函数：将平面列表重建为嵌套目录结构 ---
def rebuild_hierarchical_catalog(flat_nodes: list) -> list:
    """
    Reconstructs a hierarchical chapter structure from a flat list of nodes,
    based on 'generated_path_id' and 'pid'.
    Returns a list of top-level chapters.
    """
    node_map = {node['generated_path_id']: node.copy() for node in flat_nodes}

    # Initialize children list for all nodes
    for node_data in node_map.values():
        node_data['children'] = []

    root_chapters = []

    for node_id, node_data in node_map.items():
        pid = node_data.get('pid')
        if pid is None or str(pid).lower() == "null" or pid == "":
            root_chapters.append(node_data)
        elif pid in node_map:  # Ensure parent exists in the filtered set
            node_map[pid]['children'].append(node_data)
        # else: orphan node, which shouldn't happen if filtering logic is correct and roots are handled

    # Sort children for consistent order
    for node_data in node_map.values():
        node_data['children'].sort(key=lambda x: x.get('generated_path_id', ''))

    root_chapters.sort(key=lambda x: x.get('generated_path_id', ''))

    # Recursively clean up pid from the output if desired for frontend
    def clean_node(node):
        node.pop('pid', None)
        if node.get('children'):
            node['children'] = [clean_node(child) for child in node['children']]
        return node

    return [clean_node(root) for root in root_chapters]


# --- 外部脚本执行函数 ---
def run_processing_pipeline_in_thread(project_id: str, textbook_base_name_unique: str,
                                      original_filename_for_subscript: str,
                                      file_type_tag: str):  # <--- 新增 file_type_tag 参数
    """
    在后台线程中运行一系列 Python 脚本来处理上传的文件。
    Args:
        project_id (str): 当前项目的ID。
        textbook_base_name_unique (str): 唯一的教材基础名 (例如 "Essay", "Essay_1")。
        original_filename_for_subscript (str): 原始上传的文件名 (例如 "Essay.pdf")。
        file_type_tag (str): 文件的类型标签 ('textbook' 或 'question')。
    """
    print(
        f"\n--- Thread starting background processing pipeline for Project '{project_id}', File '{textbook_base_name_unique}' (Original: '{original_filename_for_subscript}', Type: '{file_type_tag}') ---")
    current_script_dir = Path(__file__).parent.resolve()

    # 构建项目下的 uploads 目录路径
    project_uploads_dir = current_script_dir / "uploads" / project_id
    # 确保这个目录存在
    if not project_uploads_dir.exists():
        print(f"ERROR: Project uploads directory '{project_uploads_dir}' not found. Cannot proceed with processing.")
        return

    scripts_to_run = []
    if file_type_tag == 'textbook':
        scripts_to_run = [
            ("images_and_ocr.py", project_id, textbook_base_name_unique, original_filename_for_subscript),
            ("get_catalog.py", project_id, textbook_base_name_unique, original_filename_for_subscript),
            ("get_segment.py", project_id, textbook_base_name_unique, original_filename_for_subscript),
            # ("embedding.py", project_id, f"{textbook_base_name_unique}_dir"), # <--- 关键修改：跳过 embedding.py 执行
        ]
    elif file_type_tag == 'question':
        print(
            f"File type is 'question'. No background processing scripts will be run for '{original_filename_for_subscript}'.")
        # 直接返回，表示处理完成（但实际是跳过处理）
        project = get_project_by_id(project_id)
        if project:
            for file_meta in project['files_metadata']:
                # 题目文件，标记为未处理且无错误
                if file_meta['id'] == textbook_base_name_unique + '_dir':
                    file_meta['is_processed'] = False  # 不进行复杂处理，所以始终为 False
                    file_meta['processing_error'] = "Question file, no background processing."
                    print(
                        f"File '{file_meta['name']}' in project '{project_id}' handled as 'question' type. No processing scripts run.")
                    break
            save_projects_data()
        print(
            f"--- Background processing pipeline for Project '{project_id}', File '{textbook_base_name_unique}' (Type: 'question') finished. ---")
        return  # 题目文件直接结束线程

    env = os.environ.copy()
    if os.getenv("DASHSCOPE_API_KEY"):  # DashScope key is used by get_catalog.py, get_segment.py
        env['DASHSCOPE_API_KEY'] = os.getenv("DASHSCOPE_API_KEY")
    if os.getenv(
            "DEEPSEEK_API_KEY"):  # DeepSeek key might be used by embeddings for BERT if it calls DeepSeek, but usually not. It's for search_similar.py's internal LLM use.
        env['DEEPSEEK_API_KEY'] = os.getenv("DEEPSEEK_API_KEY")

    python_executable = sys.executable

    for script_name, *args_for_script in scripts_to_run:
        script_path = current_script_dir / script_name
        if not script_path.exists():
            print(f"WARNING: Script '{script_name}' not found at {script_path}, skipping.")
            continue

        command_args_str = [str(arg) for arg in args_for_script]
        command = [python_executable, str(script_path)] + command_args_str

        print(f"Executing background command: {' '.join(command)}")

        try:
            process = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding='gbk',
                env=env,
                cwd=current_script_dir,
                errors='replace'
            )

            stdout_content = process.stdout
            stderr_content = process.stderr

            if process.returncode == 0:
                print(
                    f"Script '{script_name}' for Project '{project_id}', File '{textbook_base_name_unique}' completed successfully.")
                if stdout_content.strip():
                    print(f"  Stdout:\n{stdout_content}")
                else:
                    print("  Stdout: (empty)")
                if stderr_content.strip():
                    print(f"  Stderr:\n{stderr_content}")
                else:
                    print("  Stderr: (empty)")
            else:
                print(
                    f"ERROR: Script '{script_name}' for Project '{project_id}', File '{textbook_base_name_unique}' failed with exit code {process.returncode}.")
                print(f"  Stdout:\n{stdout_content}")
                print(f"  Stderr:\n{stderr_content}")
                # If a script fails, update file processing status to indicate failure
                project = get_project_by_id(project_id)
                if project:
                    for file_meta in project['files_metadata']:
                        if file_meta['id'] == textbook_base_name_unique + '_dir':
                            file_meta['is_processed'] = False  # Mark as not successfully processed
                            file_meta['processing_error'] = f"Script '{script_name}' failed."
                            print(
                                f"Updated file '{file_meta['name']}' in project '{project_id}' to is_processed=False due to script error.")
                            break
                    save_projects_data()
                return  # Stop pipeline on first error

        except Exception as e:
            print(
                f"ERROR: Exception while running script '{script_name}' for Project '{project_id}', File '{textbook_base_name_unique}': {e}")
            project = get_project_by_id(project_id)
            if project:
                for file_meta in project['files_metadata']:
                    if file_meta['id'] == textbook_base_name_unique + '_dir':
                        file_meta['is_processed'] = False  # Mark as not successfully processed
                        file_meta['processing_error'] = f"Exception running script '{script_name}': {str(e)}"
                        print(
                            f"Updated file '{file_meta['name']}' in project '{project_id}' to is_processed=False due to exception.")
                        break
                save_projects_data()
            return

    print(
        f"--- Background processing pipeline for Project '{project_id}', File '{textbook_base_name_unique}' finished. ---")

    # If all scripts completed successfully, update frontend file status
    project = get_project_by_id(project_id)
    if project:
        for file_meta in project['files_metadata']:
            # Here, file_meta['id'] is the unique_file_dir_name + '_dir'
            if file_meta['id'] == textbook_base_name_unique + '_dir':
                file_processed_dir = Path(UPLOAD_FOLDER) / project_id / file_meta['id']

                # <--- 关键修改：为演示目的，只检查 catalog_with_segments.json
                if (file_processed_dir / "catalog_with_segments.json").exists():
                    file_meta['is_processed'] = True
                    file_meta.pop('processing_error', None)  # Clear any previous error
                    print(
                        f"Updated file '{file_meta['name']}' in project '{project_id}' to is_processed=True (DEMO MODE).")
                else:
                    file_meta['is_processed'] = False
                    file_meta[
                        'processing_error'] = "Missing final processed files (catalog_with_segments.json required for demo)."
                    print(
                        f"WARNING: File '{file_meta['name']}' in project '{project_id}' not fully processed after pipeline completion due to missing final files.")
                break
        save_projects_data()


# --- API 路由 ---

# 0. 项目管理路由
@app.route('/api/projects', methods=['GET'])
@cross_origin()
def get_projects():
    # 仅返回项目列表，不包含内部详细数据，减少传输量
    project_list_minimal = [
        {'id': p['id'], 'name': p['name'], 'created_at': p['created_at']}
        for p in projects_data
    ]
    return jsonify(project_list_minimal)


@app.route('/api/projects', methods=['POST'])
@cross_origin()
def create_project():
    data = request.get_json()
    project_name = data.get('projectName')
    if not project_name:
        return jsonify({'error': 'Project name is required.'}), 400

    project_id = f"p{int(time.time() * 1000)}"  # 简单的时间戳ID

    # 在 uploads 目录下为项目创建专属文件夹
    project_uploads_path = Path(UPLOAD_FOLDER) / project_id
    try:
        project_uploads_path.mkdir(parents=True, exist_ok=True)
        print(f"Created project uploads directory: {project_uploads_path}")
    except Exception as e:
        return jsonify({'error': f'Failed to create project directory: {str(e)}'}), 500

    new_project = {
        'id': project_id,
        'name': project_name,
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'files_metadata': [],  # 每个项目有自己的文件列表
        'chat_history': [],  # 每个项目有自己的聊天历史
        'chat_messages': {},  # 每个项目有自己的聊天消息字典
    }
    projects_data.append(new_project)
    save_projects_data()
    return jsonify({'message': 'Project created successfully', 'project': new_project}), 201


# 删除项目路由
@app.route('/api/projects/<project_id>', methods=['DELETE'])
@cross_origin()
def delete_project(project_id):
    global projects_data  # 需要声明使用全局变量
    project_index_to_delete = -1
    project_name_to_delete = "未知项目"

    for i, p in enumerate(projects_data):
        if p['id'] == project_id:
            project_index_to_delete = i
            project_name_to_delete = p['name']
            break

    if project_index_to_delete == -1:
        print(f"ERROR: Attempted to delete non-existent project with ID: {project_id}")
        return jsonify({'error': 'Project not found'}), 404

    # 1. 从内存中的数据结构移除项目
    projects_data.pop(project_index_to_delete)
    save_projects_data()  # 保存更新后的项目数据

    # 2. 删除对应的文件目录
    project_dir_path = Path(UPLOAD_FOLDER) / project_id
    if project_dir_path.exists() and project_dir_path.is_dir():
        try:
            shutil.rmtree(project_dir_path)
            print(f"Successfully deleted project directory: {project_dir_path}")
        except Exception as e:
            print(f"ERROR: Failed to delete project directory '{project_dir_path}': {e}", file=sys.stderr)
            # 这里的处理方式取决于你的容错需求：
            # 如果目录删除失败但数据已移除，可以考虑记录日志或通知管理员。
            # 对于客户端，通常认为项目已被“删除”（数据层已移除），文件系统清理是后台任务。
            return jsonify({
                               'message': f'Project "{project_name_to_delete}" deleted, but failed to remove associated files. Please check server logs.',
                               'error_detail': str(e)}), 202
    else:
        print(
            f"WARNING: Project directory '{project_dir_path}' not found or not a directory for project ID '{project_id}'. No files to delete.")

    print(f"Project '{project_name_to_delete}' (ID: {project_id}) deleted successfully.")
    return jsonify({'message': f'Project "{project_name_to_delete}" deleted successfully'}), 200


# 1. 提供静态文件 (上传的文件)
@app.route('/uploads/<project_id>/<path:filename_with_path>')  # <--- URL结构现在是 /uploads/project_id/file_path
@cross_origin()
def uploaded_file_endpoint(project_id, filename_with_path):  # <--- 接收 project_id
    print(f"\n--- DEBUG: Serving file request for Project '{project_id}' ---")
    print(f"Requested filename (from URL): {filename_with_path}")

    # 顶级目录是 project_id，内部才是文件处理目录
    base_uploads_path = Path(UPLOAD_FOLDER) / project_id

    path_parts = Path(filename_with_path).parts  # 例如 "Essay_dir/Essay.pdf" 或 "Essay_dir/images_dir/page_0001.jpg"

    if len(path_parts) >= 1:  # 至少应该有文件名
        # 尝试从处理过的文件目录提供 (例如 project_id/Essay_dir/Essay.pdf)
        if path_parts[0].endswith('_dir'):  # 检查第一个部分是否是 *_dir 格式的文件夹名
            unique_file_dir_name = path_parts[0]  # 例如 "Essay_dir"
            relative_path_inside_unique_dir = Path(*path_parts[1:])  # 例如 "Essay.pdf" 或 "images_dir/page_0001.jpg"

            full_path_to_serve = base_uploads_path / unique_file_dir_name / relative_path_inside_unique_dir

            if full_path_to_serve.exists() and full_path_to_serve.is_file():
                print(f"Attempting to serve from project processed directory: {full_path_to_serve}")
                return send_from_directory(base_uploads_path / unique_file_dir_name,
                                           str(relative_path_inside_unique_dir))

        # 兼容处理直接在 project_id 目录下的文件 (如果文件没有自己的_dir，或者就是原始pdf)
        # 例如 project_id/file.pdf
        full_path_in_project_root = base_uploads_path / filename_with_path
        if full_path_in_project_root.exists() and full_path_in_project_root.is_file():
            print(f"Attempting to serve from project root: {full_path_in_project_root}")
            return send_from_directory(base_uploads_path, filename_with_path)

    print(f"ERROR: File '{filename_with_path}' not found on server in project '{project_id}' in expected locations.")
    return jsonify({'error': 'File not found on server.',
                    'detail': f'File {filename_with_path} does not exist in project {project_id}.'}), 404


# 2. 获取文件列表 (显示原始PDF和其处理状态)
@app.route('/api/projects/<project_id>/files', methods=['GET'])  # <--- 新路由
@cross_origin()
def get_project_files(project_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    files_on_disk = []
    # 遍历项目专属的 uploads 目录，查找所有 *_dir 结尾的文件夹
    project_uploads_path = Path(UPLOAD_FOLDER) / project_id
    if not project_uploads_path.is_dir():
        # 如果项目目录不存在，说明文件可能被手动删除了，此时清空项目内文件元数据
        if project['files_metadata']:
            project['files_metadata'] = []
            save_projects_data()
        return jsonify({'files': []}), 200  # 项目目录不存在，返回空列表

    for item_name in os.listdir(project_uploads_path):
        item_path = project_uploads_path / item_name
        if item_path.is_dir() and item_name.endswith('_dir'):
            # 这是一个处理过的教材目录
            # 我们需要找到这个目录下的原始文件
            original_file_found = None
            file_type_tag_from_meta = 'unknown'
            processing_error_from_meta = None

            # 尝试从元数据中获取文件类型tag和错误信息
            meta_entry = next((fm for fm in project['files_metadata'] if fm['id'] == item_name), None)
            if meta_entry:
                original_file_found = Path(item_path) / meta_entry['name']
                file_type_tag_from_meta = meta_entry.get('file_type_tag', 'unknown')
                processing_error_from_meta = meta_entry.get('processing_error')
            else:  # 如果元数据中没有，尝试猜测或默认
                # 寻找该目录下第一个pdf/docx/txt文件作为原始文件
                for f in item_path.iterdir():
                    if f.is_file() and f.suffix.lower() in ['.pdf', '.docx', '.txt']:
                        original_file_found = f
                        break
                # 默认处理为教材，如果实际是题目，则前端显示'未处理'且后端不处理
                file_type_tag_from_meta = 'textbook'

            if original_file_found and original_file_found.is_file():
                is_processed_flag = False
                if file_type_tag_from_meta == 'textbook':
                    # 教材类文件，检查 catalog_with_segments.json
                    is_processed_flag = (item_path / "catalog_with_segments.json").exists()
                elif file_type_tag_from_meta == 'question':
                    # 题目类文件，is_processed 始终为 False (不进行复杂后台处理)
                    is_processed_flag = False

                files_on_disk.append({
                    'id': item_name,  # <--- 关键：使用目录名作为文件的唯一ID (如 "Essay_dir", "Essay_1_dir")
                    'name': original_file_found.name,  # 显示原始文件名 (如 "Essay.pdf")
                    'size': f"{round(original_file_found.stat().st_size / (1024 * 1024), 2)}MB",
                    'type': original_file_found.suffix.lower().replace('.', ''),  # 从文件扩展名获取类型
                    'uploadDate': datetime.fromtimestamp(original_file_found.stat().st_mtime).strftime(
                        '%Y-%m-%d %H:%M'),
                    'file_type_tag': file_type_tag_from_meta,  # <--- 关键：存储文件类型标签
                    'is_processed': is_processed_flag,
                    'processed_dir_name': item_name,  # 存储文件夹名，用于预览/RAG查找
                    'processing_error': processing_error_from_meta  # 传递处理错误信息
                })

    # 更新项目内部的 files_metadata，并保存
    project['files_metadata'] = files_on_disk
    save_projects_data()  # 保存整个项目数据
    return jsonify(project['files_metadata'])


# 3. 上传文件
@app.route('/api/projects/<project_id>/upload', methods=['POST'])  # <--- 新路由
@cross_origin()
def upload_file_to_project(project_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    if 'file' not in request.files:
        return jsonify({'error': 'No file part in the request. Make sure your form field name is "file".'}), 400

    file = request.files['file']
    file_type_tag = request.form.get('file_type_tag', 'unknown')  # <--- 关键：接收文件类型标签

    if file.filename == '':
        return jsonify({'error': 'No selected file or empty filename.'}), 400

    original_filename = file.filename  # 原始文件名，如 "Essay.pdf"
    name_without_ext, ext = os.path.splitext(original_filename)  # "Essay", ".pdf"

    # 生成唯一的教材基础名 (例如 "Essay", "Essay_1")
    textbook_base_name_unique = secure_filename(name_without_ext)
    if not textbook_base_name_unique:
        textbook_base_name_unique = f"uploaded_book_{int(time.time() * 1000)}"

    # 生成唯一的处理目录名 (例如 "Essay_dir", "Essay_1_dir")
    # 这个目录将位于项目专属的 uploads 文件夹内部
    textbook_dir_full_name = f"{textbook_base_name_unique}_dir"
    counter = 1
    project_uploads_path = Path(UPLOAD_FOLDER) / project_id  # 项目专属的uploads目录
    # 循环确保目录名绝对唯一 (在项目内部唯一)
    while project_uploads_path.joinpath(textbook_dir_full_name).exists():
        textbook_dir_full_name = f"{textbook_base_name_unique}_{counter}_dir"
        counter += 1

    textbook_processing_dir = project_uploads_path / textbook_dir_full_name
    textbook_processing_dir.mkdir(parents=True, exist_ok=True)  # 确保创建了唯一的目录

    # 将原始文件保存到这个唯一的目录下，使用其原始文件名
    target_file_path_in_unique_dir = textbook_processing_dir / original_filename

    try:
        file.save(str(target_file_path_in_unique_dir))
        print(f"Original file saved to: {target_file_path_in_unique_dir}")

        file_type = ext.replace('.', '') if ext else 'unknown'
        new_file_meta = {
            'id': textbook_dir_full_name,  # <--- 关键：使用唯一的目录名作为文件ID
            'name': original_filename,  # <--- 显示原始文件名
            'size': f"{round(target_file_path_in_unique_dir.stat().st_size / (1024 * 1024), 2)}MB",
            'type': file_type,
            'uploadDate': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'file_type_tag': file_type_tag,  # <--- 关键：存储文件类型标签
            'is_processed': False,  # 初始标记为未处理
            'processed_dir_name': textbook_dir_full_name,  # 记录将来会处理到的目录名
        }

        # 将新文件元数据添加到当前项目的 files_metadata 列表
        project['files_metadata'].append(new_file_meta)
        save_projects_data()  # 保存整个项目数据

        print(
            f"Launching background processing for Project '{project_id}', File '{textbook_base_name_unique}' (folder: '{textbook_dir_full_name}', original_filename: '{original_filename}', Type: '{file_type_tag}')...")
        # <--- 关键：传递 project_id，唯一的教材基础名，原始文件名和文件类型给后台线程
        thread = threading.Thread(target=run_processing_pipeline_in_thread,
                                  args=(project_id, textbook_base_name_unique, original_filename, file_type_tag))
        thread.start()

        return jsonify({
            'message': 'File uploaded successfully. Processing started in background.',
            'fileName': original_filename,
            'fileId': new_file_meta['id'],  # 返回唯一的ID
            'fileTypeTag': file_type_tag,
            'is_processed': False
        }), 200
    except Exception as e:
        print(f"Error saving file or starting processing: {e}")
        return jsonify({'error': f'Failed to upload file or start processing: {str(e)}'}), 500


# 4. 获取对话历史列表
@app.route('/api/projects/<project_id>/chat-history', methods=['GET'])  # <--- 新路由
@cross_origin()
def get_chat_history(project_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    history_with_files = []
    # 这里的 mock_chat_history 替换为 project['chat_history']
    for chat_entry in project['chat_history']:
        entry_copy = chat_entry.copy()
        entry_copy['related_files_meta'] = []
        for file_id in entry_copy.get('related_file_ids', []):
            # 这里的 mock_files_metadata 替换为 project['files_metadata']
            file_meta = next((f for f in project['files_metadata'] if f['id'] == file_id), None)
            if file_meta:
                entry_copy['related_files_meta'].append(file_meta)
        history_with_files.append(entry_copy)
    return jsonify(history_with_files)


# 5. 获取某个对话的消息
@app.route('/api/projects/<project_id>/chat/<chat_id>/messages', methods=['GET'])  # <--- 新路由
@cross_origin()
def get_chat_messages(project_id, chat_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    messages = project['chat_messages'].get(chat_id, [])  # 从项目数据中获取消息

    related_files_meta = []
    chat_entry = next((c for c in project['chat_history'] if c['id'] == chat_id), None)  # 从项目数据中获取聊天条目
    if chat_entry and chat_entry.get('related_file_ids'):
        for file_id in chat_entry['related_file_ids']:
            file_meta = next((f for f in project['files_metadata'] if f['id'] == file_id), None)  # 从项目文件元数据中获取
            if file_meta:
                related_files_meta.append(file_meta)

    return jsonify({"messages": messages, "related_files_meta": related_files_meta})


# 6. 发送新消息到大模型
@app.route('/api/projects/<project_id>/chat', methods=['POST'])  # <--- 新路由
@cross_origin()
def send_chat_message(project_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    data = request.get_json()
    user_message_content = data.get('message')
    chat_id = data.get('chatId')
    model_settings = data.get('modelSettings', {})
    related_file_ids = data.get('relatedFileIds', [])

    if not user_message_content:
        return jsonify({'error': 'Message content cannot be empty'}), 400

    new_chat_id = chat_id
    current_chat_entry = None

    if not new_chat_id:
        new_chat_id = f'c{int(time.time() * 1000)}'
        new_chat_title = f"新对话 {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        current_chat_entry = {
            'id': new_chat_id,
            'title': new_chat_title,
            'lastActive': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'related_file_ids': related_file_ids
        }
        project['chat_history'].insert(0, current_chat_entry)  # 插入到项目聊天历史
        project['chat_messages'][new_chat_id] = []  # 初始化项目聊天消息
    else:
        for chat_entry in project['chat_history']:  # 从项目聊天历史查找
            if chat_entry['id'] == new_chat_id:
                current_chat_entry = chat_entry
                current_chat_entry['related_file_ids'] = related_file_ids
                break

    current_chat_msgs = project['chat_messages'].get(new_chat_id, [])  # 从项目聊天消息获取
    current_chat_msgs.append({
        'id': f'm_user_{int(time.time() * 1000)}',
        'sender': 'user',
        'content': user_message_content,
        'timestamp': datetime.now().strftime('%H:%M')
    })
    project['chat_messages'][new_chat_id] = current_chat_msgs  # 更新项目聊天消息

    final_ai_response_json = {"text": "抱歉，AI助手暂时无法响应。请确保您的API Key正确且网络畅通。", "citations": []}

    try:
        messages_for_llm = []

        context_str = ""
        citations_for_response = []

        all_knowledge_points = []
        if related_file_ids:
            print(f"DEBUG RAG: Retrieving knowledge points from selected files for RAG: {related_file_ids}")
            for file_id in related_file_ids:
                # 从项目文件元数据中查找
                file_meta = next((f for f in project['files_metadata'] if f['id'] == file_id), None)

                # 只有教材类型且已处理的文件才能进行RAG (RAG本身不做改变，但如果embedding被跳过，效果可能打折扣)
                if file_meta and file_meta.get('file_type_tag') == 'textbook' and file_meta.get(
                        'is_processed') and file_meta.get('processed_dir_name'):
                    # 构建处理目录路径： uploads/project_id/processed_dir_name
                    processed_dir_path = Path(UPLOAD_FOLDER) / project_id / file_meta['processed_dir_name']
                    catalog_with_segments_path = processed_dir_path / "catalog_with_segments.json"

                    if catalog_with_segments_path.exists():
                        try:
                            with open(catalog_with_segments_path, 'r', encoding='utf-8') as f:
                                catalog_data = json.load(f)

                            def collect_knowledge_points_recursive_for_rag(nodes, current_chapter_path=None):
                                kps = []
                                for node in nodes:
                                    node_path = node.get('generated_path_id', 'unknown_id')
                                    current_full_chapter_path = f"{current_chapter_path}.{node_path}" if current_chapter_path else node_path

                                    if node.get('knowledge_points') and isinstance(node['knowledge_points'], list):
                                        for kps_idx, kp_text in enumerate(node['knowledge_points']):
                                            kps.append({
                                                "id": f"{current_full_chapter_path}_{kps_idx}",
                                                "text": kp_text,
                                                "doc_name": file_meta['name'],
                                                "chapter_name": node.get('name', '未知章节')
                                            })
                                    if node.get('children') and isinstance(node['children'], list):
                                        kps.extend(collect_knowledge_points_recursive_for_rag(node['children'],
                                                                                              current_full_chapter_path))
                                return kps

                            if catalog_data.get('chapters') and isinstance(catalog_data['chapters'], list):
                                current_file_kps = collect_knowledge_points_recursive_for_rag(catalog_data['chapters'])
                                all_knowledge_points.extend(current_file_kps)
                                print(
                                    f"DEBUG RAG: Loaded {len(current_file_kps)} knowledge points from {file_meta['name']} in project {project_id}.")

                        except Exception as e:
                            print(
                                f"ERROR RAG: Failed to load or parse catalog_with_segments.json for {file_meta['name']} in project {project_id}: {e}")
                    else:
                        print(
                            f"WARNING RAG: catalog_with_segments.json not found for {file_meta['name']} in project {project_id} at {catalog_with_segments_path}. Skipping.")
                elif file_meta.get('file_type_tag') == 'question':
                    print(f"DEBUG RAG: Skipping RAG for 'question' type file: {file_meta.get('name', file_id)}.")
                else:  # Fallback for non-textbook or unprocessed files
                    print(
                        f"WARNING RAG: File '{file_meta.get('name', file_id)}' in project {project_id} is not processed or not 'textbook' type. Falling back to raw text chunking for RAG.")

                    # 构建原始文件路径：uploads/project_id/processed_dir_name/original_filename
                    # 对于未处理的文件，file_meta['processed_dir_name'] 可能不存在，直接使用 file_meta['id'] (即 unique_file_dir_name)
                    file_path_for_raw = Path(UPLOAD_FOLDER) / project_id / file_meta.get('processed_dir_name',
                                                                                         file_meta['id']) / file_meta[
                                            'name']

                    chunks_from_raw, extract_error = extract_text_from_file(file_path_for_raw, file_meta['type'])
                    if chunks_from_raw:
                        for chunk in chunks_from_raw:
                            all_knowledge_points.append({
                                "id": f"{file_id}_{chunk['id']}",
                                "text": chunk['text'],
                                "doc_name": file_meta['name'],
                                "chapter_name": "（未处理）"
                            })
                    else:
                        print(
                            f"WARNING RAG: Failed to extract raw text chunks from {file_meta['name']} in project {project_id}: {extract_error}. No context for this file.")

        print(f"DEBUG RAG: Total knowledge points collected for RAG: {len(all_knowledge_points)}")
        # 仅在有知识点时进行jieba分词和评分，否则直接跳过
        relevant_chunks_for_llm = []
        if all_knowledge_points:
            # 引入jieba，如果未安装可能会报错
            try:
                import jieba
            except ImportError:
                print("WARNING: jieba not installed. Falling back to simple keyword matching for RAG.")
                # 如果jieba未安装，则回退到简单的空格分词
                query_words = set(user_message_content.lower().split())
                stop_words = {"的", "了", "是", "在", "我", "你", "他", "她", "它", "分析", "文件", "请", "如何",
                              "什么", "这个", "那个", "根据", "文档", "回答", "问题", "并", "和", "或", "等", "以",
                              "从", "中", "于", "对", "为", "所", "其", "则", "将", "与", "关于", "有", "也", "都",
                              "还", "是什么", "的", "地", "得"}
                query_words = {word for word in query_words if len(word) > 1 and word not in stop_words}

                scored_chunks = []
                for kp in all_knowledge_points:
                    if not kp.get('text'):
                        continue
                    kp_text_words = set(kp['text'].lower().split())
                    score = sum(1 for word in query_words if word in kp_text_words)
                    if score > 0:
                        scored_chunks.append((score, kp))
            else:  # 如果jieba已安装
                query_segmented_words = jieba.lcut(user_message_content.lower())

                stop_words = {"的", "了", "是", "在", "我", "你", "他", "她", "它", "分析", "文件", "请", "如何",
                              "什么", "这个", "那个", "根据", "文档", "回答", "问题", "并", "和", "或", "等", "以",
                              "从", "中", "于", "对", "为", "所", "其", "则", "将", "与", "关于", "有", "也", "都",
                              "还", "是什么", "的", "地", "得"}
                query_words = {word for word in query_segmented_words if len(word) > 1 and word not in stop_words}

                print(f"DEBUG RAG: Processed Query Words (jieba): {query_words}")

                scored_chunks = []
                for kp in all_knowledge_points:
                    if not kp.get('text'):
                        continue

                    kp_segmented_words = set(jieba.lcut(kp['text'].lower()))

                    score = sum(1 for word in query_words if word in kp_segmented_words)

                    if score > 0:
                        scored_chunks.append((score, kp))

            print(
                f"DEBUG RAG: Scored KPs (before sort/limit, jieba): {[(s, kp['doc_name'], kp['chapter_name']) for s, kp in scored_chunks[:min(5, len(scored_chunks))]]}...")

            scored_chunks.sort(key=lambda x: x[0], reverse=True)

            MAX_CONTEXT_CHUNKS = 8
            citation_id_counter = 1
            seen_kp_identifiers = set()

            for score, kp in scored_chunks:
                if citation_id_counter > MAX_CONTEXT_CHUNKS:
                    break

                kp_identifier = f"{kp['doc_name']}_{kp['chapter_name']}_{kp['text']}"
                if kp_identifier in seen_kp_identifiers:
                    continue

                relevant_chunks_for_llm.append({
                    "id": f"[{citation_id_counter}]",
                    "text": kp['text'],
                    "original_doc_name": kp['doc_name']
                })

                citations_for_response.append({
                    "id": str(citation_id_counter),
                    "doc_name": kp['doc_name'],
                    "text": kp['text']
                })
                seen_kp_identifiers.add(kp_identifier)
                citation_id_counter += 1

            print(
                f"DEBUG RAG: Final Relevant KPs for LLM (jieba): {[(c['original_doc_name'], c['text'][:50]) for c in relevant_chunks_for_llm]}")

        system_instruction_prefix = "你是一个严谨、专业的AI助手，擅长分析文档并提供清晰、准确、且带有引用的回答。你必须严格依据提供的参考资料进行回答，不允许虚构或依赖你的预训练知识回答参考资料中没有的信息。"

        user_prompt_content = f"用户问题：{user_message_content}"

        if related_file_ids and relevant_chunks_for_llm:
            context_str += "以下是一些用户选择的参考资料。请注意，你的回答必须完全基于这些资料，如果答案不在其中，请明确说明。\n\n"
            for chunk_info in relevant_chunks_for_llm:
                context_str += f"### 参考资料：文档 '{chunk_info['original_doc_name']}'，片段 {chunk_info['id']}：来自章节 '{chunk_info.get('chapter_name', '未知章节')}'\n"
                context_str += "```text\n"
                context_str += chunk_info['text'] + "\n"
                context_str += "```\n\n"

            context_str += "请根据上述提供的参考资料，准确、简洁地回答以下用户的问题。**在回答中，如果使用了参考资料，务必在相关内容后用方括号加数字的形式引用，例如：某个概念的定义[1]，某个论点[2]。** 如果参考资料中没有提及相关信息，请直接回答‘抱歉，根据我当前掌握的资料，无法从提供的参考资料中找到此问题的答案。’\n\n"
        elif related_file_ids and not relevant_chunks_for_llm:
            context_str = "用户提问，但无法从选择的文件中找到与问题相关的参考资料。我将完全根据我已有的知识进行回答。如果您的原始问题是关于特定文档的，请确保文档内容中包含您的问题。请注意，我无法访问您本地的文件。"
        else:
            context_str = "用户提问，未选择任何参考资料。我将完全根据我已有的知识进行回答。\n\n"

        messages_for_llm.append({"role": "system", "content": system_instruction_prefix + context_str})
        messages_for_llm.append({"role": "user", "content": user_prompt_content})

        selected_model = model_settings.get('model', DEFAULT_DEEPSEEK_MODEL)
        if selected_model not in ["deepseek-chat", "deepseek-coder"]:
            print(
                f"Warning: Selected model '{selected_model}' might not be a valid DeepSeek model. Using default: {DEFAULT_DEEPSEEK_MODEL}")
            selected_model = DEFAULT_DEEPSEEK_MODEL

        print(
            f"Calling DeepSeek LLM with model: {selected_model}, temperature: {model_settings.get('temperature', 0.7)}")
        print(f"Prompt sent to LLM:\n{messages_for_llm}")

        completion = openai_client_for_chat_rag.chat.completions.create(
            model=selected_model,
            messages=messages_for_llm,
            temperature=model_settings.get('temperature', 0.7),
            timeout=30.0
        )

        ai_response_content = completion.choices[0].message.content
        print(f"AI Response: {ai_response_content}")

        final_ai_response_json["text"] = ai_response_content
        final_ai_response_json["citations"] = citations_for_response

    except APIConnectionError as e:
        print(f"ERROR: DeepSeek API Connection Error: {e}")
        final_ai_response_json["text"] = f"无法连接到DeepSeek服务，请检查网络或代理设置: {str(e)}"
        return jsonify({'aiResponse': final_ai_response_json}), 503
    except RateLimitError as e:
        print(f"ERROR: DeepSeek API Rate Limit Exceeded: {e}")
        final_ai_response_json["text"] = f"请求DeepSeek太频繁，请稍后再试: {str(e)}"
        return jsonify({'aiResponse': final_ai_response_json}), 429
    except APIStatusError as e:
        print(
            f"ERROR: DeepSeek API returned non-200 status: {e.status_code} - {e.response.json().get('message', '未知错误')}")
        if e.status_code == 401:
            final_ai_response_json["text"] = f"DeepSeek服务认证失败，请检查API Key是否有效或账户余额。"
            return jsonify({'aiResponse': final_ai_response_json}), 401
        else:
            final_ai_response_json[
                "text"] = f"DeepSeek服务内部错误: {e.status_code} - {e.response.json().get('message', '未知错误')}"
            return jsonify({'aiResponse': final_ai_response_json}), e.status_code
    except Exception as e:
        print(f"ERROR: General error calling DeepSeek API: {e}")
        final_ai_response_json["text"] = f"抱歉，DeepSeek助手在处理您的请求时遇到问题: {str(e)}"
        return jsonify({'aiResponse': final_ai_response_json}), 500

    current_chat_msgs.append({
        'id': f'm_ai_{int(time.time() * 1000) + 1}',
        'sender': 'ai',
        'content': final_ai_response_json['text'],
        'timestamp': datetime.now().strftime('%H:%M'),
        'citations_data': final_ai_response_json['citations']
    })
    project['chat_messages'][new_chat_id] = current_chat_msgs  # 更新项目聊天消息

    if current_chat_entry:
        current_chat_entry['lastActive'] = datetime.now().strftime('%Y-%m-%d %H:%M')
        current_chat_entry['related_file_ids'] = related_file_ids

    save_projects_data()  # 保存整个项目数据

    response_data = {
        'aiResponse': final_ai_response_json,
        'chatId': new_chat_id
    }
    if not chat_id:
        response_data['newChatId'] = new_chat_id
        response_data['newChatTitle'] = new_chat_title
    return jsonify(response_data), 200


# 7. 导出对话为 DOCX 文件
@app.route('/api/projects/<project_id>/export-chat/<chat_id>', methods=['GET'])  # <--- 新路由
@cross_origin()
def export_chat(project_id, chat_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    messages = project['chat_messages'].get(chat_id, [])  # 从项目数据中获取消息

    if not messages:
        return jsonify({'error': 'No messages found for this chat ID.'}), 404

    chat_title = "Chat History"
    chat_entry = next((c for c in project['chat_history'] if c['id'] == chat_id), None)  # 从项目数据中获取聊天条目
    if chat_entry:
        chat_title = chat_entry.get('title', f"Chat-{chat_id}")

    safe_chat_title = secure_filename(chat_title)
    if not safe_chat_title:
        safe_chat_title = f"chat_export_{int(time.time())}"

    document = docx.Document()
    document.add_heading(f"对话历史 - {chat_title}", level=1)

    for msg in messages:
        sender = "您" if msg['sender'] == 'user' else "AI助手"
        timestamp = msg['timestamp']

        p = document.add_paragraph()
        p.add_run(f"[{timestamp}] {sender}: ").bold = True
        p.add_run(msg['content'])

        if msg['sender'] == 'ai' and msg.get('citations_data'):
            document.add_paragraph("--- 引用 ---", style='Intense Quote')
            for citation in msg['citations_data']:
                document.add_paragraph(f"[{citation['id']}] (来自 {citation['doc_name']}): {citation['text']}",
                                       style='List Paragraph')
            document.add_paragraph("-----------")

    file_stream = BytesIO()
    document.save(file_stream)
    file_stream.seek(0)

    return send_file(
        file_stream,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        as_attachment=True,
        download_name=f'{safe_chat_title}_对话历史.docx'
    )


# --- 答题方法和模板提取相关路由 ---
@app.route('/api/projects/<project_id>/templates/list', methods=['GET'])  # <--- 新路由
@cross_origin()
def list_templates(project_id):  # <--- 接收 project_id (虽然这里不直接用，但保持一致性)
    # 模板仍然是全局的，与项目无关
    templates_methods = template_manager.get_all_templates_methods()
    return jsonify(templates_methods)


@app.route('/api/projects/<project_id>/templates/extract-from-file', methods=['POST'])  # <--- 新路由
@cross_origin()
def extract_templates_from_file(project_id):  # <--- 接收 project_id
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    data = request.get_json()
    file_id = data.get('fileId')

    if not file_id:
        return jsonify({"error": "File ID is required."}), 400

    file_meta = next((f for f in project['files_metadata'] if f['id'] == file_id), None)  # 从项目数据中查找文件
    if not file_meta:
        return jsonify({"error": "File not found in project metadata."}), 404

    # 构建文件路径：uploads/project_id/file_id/file.name
    file_path = Path(UPLOAD_FOLDER) / project_id / file_meta['id'] / file_meta['name']

    if not file_path.exists():
        return jsonify(
            {"error": f"File '{file_meta['name']}' not found on disk at processed location: {file_path}"}), 404

    full_text_chunks, error_msg = extract_text_from_file(file_path, file_meta['type'])
    if error_msg or not full_text_chunks:
        print(f"DEBUG APP: Failed to extract text chunks from file: {error_msg}")
        return jsonify({"error": f"Failed to extract text from file: {str(e)}"}), 500

    full_text_content = "\n\n".join([c['text'] for c in full_text_chunks])
    file_type_display = file_meta.get('file_type_tag', '未知类型')

    qa_pairs_from_llm = []
    try:
        qa_pairs_from_llm = llm_client_for_tasks.extract_qa_pairs_from_document(
            full_text_content, document_type_tag=file_type_display
        )
        print(
            f"DEBUG APP: LLM extracted Q&A pairs (count: {len(qa_pairs_from_llm)}): {qa_pairs_from_llm[:min(3, len(qa_pairs_from_llm))]}...")

        if not isinstance(qa_pairs_from_llm, list):
            print(f"DEBUG APP: LLM extract_qa_pairs_from_document returned non-list: {qa_pairs_from_llm}")
            return jsonify(
                {"error": f"LLM failed to extract valid Q&A pairs (returned non-list): {qa_pairs_from_llm}"}), 500
    except Exception as e:
        print(f"ERROR APP: Error calling LLM for Q&A pair extraction: {e}")
        return jsonify({"error": f"Failed to extract Q&A pairs from document: {str(e)}"}), 500

    if not qa_pairs_from_llm:
        print(f"DEBUG APP: No valid Q&A pairs identified by LLM for file {file_meta['name']} in project {project_id}.")
        return jsonify({"message": "Successfully analyzed file, but no valid Q&A pairs were identified.",
                        "extracted_data": []}), 200

    added_count = 0
    extracted_templates_methods = []

    for i, qa_pair in enumerate(qa_pairs_from_llm):
        question = qa_pair.get("question")
        answer = qa_pair.get("answer")

        if question and answer:
            print(f"DEBUG APP: Processing Q&A pair {i + 1}: Q='{question[:50]}...', A='{answer[:50]}...'")
            try:
                extract_result = question_rewriter_module.extract_and_save_qa_template_method(question, answer)

                print(f"DEBUG APP: Result from question_rewriter_module for pair {i + 1}: {extract_result}")

                if "error" not in extract_result:
                    q_template = extract_result.get("question_template")
                    a_method = extract_result.get("answer_method")
                    if q_template and a_method:
                        if template_manager.add_template_method(q_template, a_method):
                            added_count += 1
                            extracted_templates_methods.append({
                                "question_template": q_template,
                                "answer_method": a_method
                            })
                            print(f"DEBUG APP: Successfully added template/method for pair {i + 1}.")
                        else:
                            print(
                                f"DEBUG APP: Template/Method for pair {i + 1} already exists or failed to add to manager.")
                    else:
                        print(
                            f"WARNING APP: LLM for template extraction returned incomplete data for pair {i + 1}: {extract_result}")
                else:
                    print(
                        f"WARNING APP: Failed to extract template/method for QA pair {i + 1} from LLM: {extract_result['error']}")
            except Exception as e:
                print(f"ERROR APP: Error processing QA pair {i + 1} for template extraction: {e}")
        else:
            print(
                f"WARNING APP: Incomplete Q&A pair returned by LLM (missing question or answer) for pair {i + 1}: {qa_pair}")

    return jsonify({"message": f"Successfully extracted and saved {added_count} templates and methods from file.",
                    "extracted_data": extracted_templates_methods}), 200


@app.route('/api/projects/<project_id>/templates/rewrite-answer', methods=['POST'])  # <--- 新路由
@cross_origin()
def rewrite_answer_api(project_id):  # <--- 接收 project_id (虽然不直接用，但保持一致性)
    data = request.get_json()
    question = data.get('question')
    original_answer = data.get('originalAnswer')
    method_index = data.get('methodIndex')

    if not all([question, original_answer, method_index is not None]):
        return jsonify({"error": "Missing question, original answer, or method index."}), 400

    try:
        rewritten_answer = question_rewriter_module.rewrite_answer_with_selected_method(
            question, original_answer, method_index
        )
        if "Error:" in rewritten_answer:
            return jsonify({"error": rewritten_answer}), 500
        return jsonify({"rewrittenAnswer": rewritten_answer}), 200
    except Exception as e:
        print(f"Error in rewrite_answer_api: {e}")
        return jsonify({"error": f"Failed to rewrite answer: {str(e)}"}), 500


# --- 新增：仪表盘/思维导图路由 ---
@app.route('/api/projects/<project_id>/dashboard/mindmap', methods=['POST'])
@cross_origin()
def generate_mindmap_for_query(project_id):
    project = get_project_by_id(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    data = request.get_json()
    file_id = data.get('fileId')
    force_filtered_orgchart = data.get('forceFilteredOrgchart', False)  # <--- 新增参数

    if not file_id:
        return jsonify({"error": "File ID is required."}), 400

    file_meta = next((f for f in project['files_metadata'] if f['id'] == file_id), None)
    if not file_meta:
        return jsonify({"error": "Selected file not found in project metadata."}), 404

    # 强制检查文件类型必须是 'textbook'
    if file_meta.get('file_type_tag') != 'textbook':
        return jsonify({"error": "仪表盘功能仅支持'教材'类型文件。请选择一个教材文件。"}), 400

    # 强制检查，必须是已处理的教材文件（即 catalog_with_segments.json 已存在）
    processed_file_dir_path = Path(UPLOAD_FOLDER) / project_id / file_id
    catalog_segments_path = processed_file_dir_path / "catalog_with_segments.json"
    if not catalog_segments_path.is_file():
        return jsonify({"error": f"所选教材 '{file_meta['name']}' 尚未完成处理。请等待或选择一个已处理的教材文件。"}), 400

    # --- 关键修改：根据 force_filtered_orgchart 标志加载不同的演示文件 ---
    target_orgchart_path = DEMO_FILTERED_ORGCHART_PATH if force_filtered_orgchart else DEMO_FULL_ORGCHART_PATH

    if not target_orgchart_path.is_file():
        print(f"ERROR: Demo orgchart file not found at {target_orgchart_path}.")
        return jsonify({"error": f"演示思维导图文件未找到: {target_orgchart_path}。请确保文件存在于指定路径。"}), 500

    try:
        with open(target_orgchart_path, 'r', encoding='utf-8') as f:
            mindmap_data_from_file = json.load(f)

        # 简单验证一下结构，确保有 'chapters' 键
        if "chapters" not in mindmap_data_from_file or not isinstance(mindmap_data_from_file["chapters"], list):
            print(
                f"ERROR: Invalid format in demo orgchart file {target_orgchart_path}. 'chapters' key missing or invalid.")
            return jsonify({"error": f"演示思维导图文件格式不正确: {target_orgchart_path}。"}), 500

        print(f"DEBUG MindMap: Loaded orgchart from demo file: {target_orgchart_path}")
        return jsonify({"mindmap_data": mindmap_data_from_file, "message": "思维导图生成成功！"}), 200

    except Exception as e:
        print(f"ERROR: Failed to load or parse demo orgchart file: {e}")
        return jsonify({"error": f"加载演示思维导图文件时发生错误: {str(e)}"}), 500


# --- 服务器启动 ---
if __name__ == '__main__':
    load_projects_data()  # <--- 加载项目数据
    print("\n--- Flask URL Map ---")
    for rule in app.url_map.iter_rules():
        print(f"Endpoint: {rule.endpoint}, Methods: {rule.methods}, Rule: {rule.rule}")
    print("---------------------\n")

    print(f"\n--- Starting Flask backend server ---")
    print(f"DeepSeek API Key loaded: {'Yes' if deepseek_api_key else 'No'}")
    print(f"DashScope API Key loaded: {'Yes' if dashscope_api_key else 'No'}")
    print(f"DeepSeek Base URL: {DEEPSEEK_BASE_URL}")
    print(f"Uploads directory: {os.path.abspath(UPLOAD_FOLDER)}")
    print(f"Projects data file: {os.path.abspath(PROJECTS_DATA_FILE)}")  # <--- 新的打印
    print(f"Templates/Methods file: {os.path.abspath(TEMPLATES_FILE)}\n")
    app.run(debug=True, port=5000)

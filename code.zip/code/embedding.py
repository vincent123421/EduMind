# notebook-backend/embedding.py

import json
import os
from pathlib import Path
import numpy as np
import torch
from transformers import BertTokenizer, BertModel
import faiss  # For FAISS indexing
import sys  # For command-line arguments
import logging  # Added for better logging
from typing import List, Optional, Dict  # <--- 确保导入 List, Optional, Dict
import argparse
import os
os.environ['TRANSFORMERS_OFFLINE'] = '0' # Ensure it's not offline mode
os.environ['HF_HOME'] = os.path.join(os.path.expanduser('~'), '.cache', 'huggingface') # Set a clear cache path
# 禁用 SSL 验证 (WARNING: 安全风险，仅用于测试)
# 这两种方法尝试一种或两种
os.environ['REQUESTS_CA_BUNDLE'] = '' # 清空 CA bundle
# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - [%(module)s.%(funcName)s] %(message)s')

# --- Constants defined as per requirements ---
BERT_MODEL = "bert-base-chinese"
CATALOG_FILENAME = "catalog.json"  # Not directly used by this script, but part of the standard set
CATALOG_SEGMENTS_FILENAME = "catalog_with_segments.json"  # Input for this script
EMBEDDING_BATCH_SIZE = 32
FAISS_INDEX_FILENAME = "knowledge_points.index"  # Output FAISS index filename
MAPPING_FILE_SUFFIX = ".mapping.json"  # Suffix for the mapping file
# TEXTBOOK_INFO_DIR_NAME = "textbook_information" # <--- REMOVED (no longer needed here)

# New constant for GPU usage, as per plan
USE_GPU = True  # Set to False to force CPU


# --- End of defined constants ---

def _extract_recursive(node_list: List[Dict], all_kps_list: List[str]):
    if not isinstance(node_list, list):
        return

    for node in node_list:
        if not isinstance(node, dict):
            continue

        if "knowledge_points" in node and node["knowledge_points"]:
            if isinstance(node["knowledge_points"], list):
                for item in node["knowledge_points"]:
                    if isinstance(item, str) and item.strip():
                        all_kps_list.append(item.strip())
                    elif isinstance(item, str):
                        logging.warning(
                            f"Empty string found in knowledge_points for node '{node.get('name', 'Unnamed Node')}'.")
                    else:
                        logging.warning(
                            f"Non-string item found in knowledge_points for node '{node.get('name', 'Unnamed Node')}': {item}")
            else:
                logging.warning(f"'knowledge_points' is not a list in node '{node.get('name', 'Unnamed Node')}'.")

        if "children" in node and isinstance(node["children"], list) and node["children"]:
            _extract_recursive(node["children"], all_kps_list)


def extract_knowledge_points_from_json(json_file_path: Path) -> List[str]:
    logging.info(f"Attempting to load JSON from: {json_file_path}")
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        logging.error(f"JSON file not found at {json_file_path}.")
        return []
    except json.JSONDecodeError as e:
        logging.error(f"Cannot decode JSON from {json_file_path}. Details: {e}")
        return []
    except Exception as e:
        logging.error(f"Unexpected error reading {json_file_path}: {e}")
        return []

    extracted_kps = []
    if "chapters" in data and isinstance(data["chapters"], list):
        _extract_recursive(data["chapters"], extracted_kps)
    else:
        logging.warning("'chapters' key not found or not a list in JSON root.")

    unique_ordered_kps = list(dict.fromkeys(extracted_kps))
    logging.info(f"Extracted {len(unique_ordered_kps)} unique knowledge points.")
    return unique_ordered_kps


def get_bert_embeddings(texts: List[str], model_name: str, batch_size: int, use_gpu_explicit: bool) -> np.ndarray:
    if not texts:
        logging.warning("No texts provided for embedding.")
        return np.array([])

    logging.info(f"Loading tokenizer and model: {model_name}...")
    try:
        tokenizer = BertTokenizer.from_pretrained(model_name)
        model = BertModel.from_pretrained(model_name)
    except Exception as e:
        logging.error(f"Error loading model/tokenizer '{model_name}': {e}")
        return np.array([])

    resolved_use_gpu = use_gpu_explicit and torch.cuda.is_available()
    device = torch.device("cuda" if resolved_use_gpu else "cpu")

    if resolved_use_gpu:
        logging.info(
            f"CUDA available, using GPU: {torch.cuda.get_device_name(0) if torch.cuda.device_count() > 0 else 'N/A'}")
    else:
        if use_gpu_explicit and not torch.cuda.is_available():
            logging.warning("GPU use was requested, but CUDA is not available. Falling back to CPU.")
        logging.info("Using CPU for embeddings.")

    model.to(device)
    model.eval()

    all_embeddings_list = []
    logging.info(f"Starting embedding for {len(texts)} texts, batch size {batch_size}...")
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i + batch_size]
        encoded_input = tokenizer(
            batch_texts, padding=True, truncation=True, return_tensors='pt', max_length=512
        )
        encoded_input = {k: v.to(device) for k, v in encoded_input.items()}

        with torch.no_grad():
            outputs = model(**encoded_input)
            last_hidden_states = outputs.last_hidden_state
            attention_mask = encoded_input['attention_mask']
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(last_hidden_states.size()).float()
            sum_embeddings = torch.sum(last_hidden_states * input_mask_expanded, 1)
            sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
            mean_pooled_embeddings = sum_embeddings / sum_mask
        all_embeddings_list.append(mean_pooled_embeddings.cpu().numpy())
        if (i // batch_size + 1) % 10 == 0:
            logging.info(f"  Processed batch {i // batch_size + 1} / {(len(texts) + batch_size - 1) // batch_size}")

    if not all_embeddings_list:
        logging.warning("No embeddings were generated.")
        return np.array([])

    embeddings_np = np.concatenate(all_embeddings_list, axis=0)
    logging.info(f"Embedding generation complete. Shape: {embeddings_np.shape}")
    return embeddings_np.astype('float32')  # FAISS expects float32


def create_and_save_faiss_index(embeddings_np: np.ndarray, output_index_path: Path) -> bool:
    if not isinstance(embeddings_np, np.ndarray) or embeddings_np.ndim != 2 or embeddings_np.size == 0:
        logging.error("Invalid or empty embeddings provided for FAISS indexing.")
        return False

    dimension = embeddings_np.shape[1]
    num_vectors = embeddings_np.shape[0]
    logging.info(f"Creating FAISS index with dimension {dimension} for {num_vectors} vectors.")

    try:
        index = faiss.IndexFlatL2(dimension)
    except Exception as e:
        logging.error(f"Error creating FAISS index object: {e}. Ensure faiss is installed.")
        return False

    logging.info(f"Adding {num_vectors} vectors to FAISS index...")
    try:
        index.add(embeddings_np)
    except Exception as e:
        logging.error(f"Error adding vectors to FAISS index: {e}")
        return False
    logging.info(f"Total vectors in index: {index.ntotal}")

    try:
        output_index_path.parent.mkdir(parents=True, exist_ok=True)  # Ensure dir exists
        logging.info(f"Saving FAISS index to: {output_index_path}")
        faiss.write_index(index, str(output_index_path))
        logging.info("FAISS index saved successfully.")
        return True
    except Exception as e:
        logging.error(f"Error saving FAISS index to {output_index_path}: {e}")
        return False


def run_embedding_generation(project_id: str, unique_file_dir_name: str):
    logging.info(
        f"\n--- Starting Embedding and Indexing Pipeline for Project: '{project_id}', File Dir: '{unique_file_dir_name}' ---")

    current_script_dir = Path(__file__).parent.resolve()
    file_processing_dir = current_script_dir / "uploads" / project_id / unique_file_dir_name
    # info_storage_dir = file_processing_dir / TEXTBOOK_INFO_DIR_NAME # <--- REMOVED (no longer used for pathing)

    input_catalog_json_path = file_processing_dir / CATALOG_SEGMENTS_FILENAME  # <--- MODIFIED: read directly from file_processing_dir
    output_faiss_index_path = file_processing_dir / FAISS_INDEX_FILENAME  # <--- MODIFIED: write directly to file_processing_dir
    mapping_file_name = Path(FAISS_INDEX_FILENAME).stem + MAPPING_FILE_SUFFIX
    output_mapping_file_path = file_processing_dir / mapping_file_name  # <--- MODIFIED: write directly to file_processing_dir

    logging.info(f"Input catalog (segments) JSON: {input_catalog_json_path}")
    logging.info(f"Output FAISS index: {output_faiss_index_path}")
    logging.info(f"Output mapping file: {output_mapping_file_path}")
    logging.info(f"BERT Model: {BERT_MODEL}")
    logging.info(f"Embedding Batch Size: {EMBEDDING_BATCH_SIZE}")
    logging.info(f"Use GPU: {USE_GPU}")

    logging.info(f"\n[Step 1/4] Extracting knowledge points from: {input_catalog_json_path}")
    knowledge_points_texts = extract_knowledge_points_from_json(input_catalog_json_path)
    if not knowledge_points_texts:
        logging.error("No knowledge points found or error during extraction. Aborting pipeline.")
        sys.exit(1)
    logging.info(f"Successfully extracted {len(knowledge_points_texts)} unique knowledge points.")

    logging.info("\n[Step 2/4] Generating BERT embeddings...")
    embeddings = get_bert_embeddings(knowledge_points_texts, BERT_MODEL, EMBEDDING_BATCH_SIZE, USE_GPU)
    if embeddings.size == 0:
        logging.error("Failed to generate embeddings. Aborting pipeline.")
        sys.exit(1)
    logging.info(f"Successfully generated {embeddings.shape[0]} embeddings with dimension {embeddings.shape[1]}.")

    logging.info("\n[Step 3/4] Creating and saving FAISS index...")
    index_saved = create_and_save_faiss_index(embeddings, output_faiss_index_path)
    if not index_saved:
        logging.error("Failed to create or save FAISS index. Aborting pipeline.")
        sys.exit(1)

    logging.info(f"\n[Step 4/4] Saving knowledge point mapping to: {output_mapping_file_path}")
    try:
        output_mapping_file_path.parent.mkdir(parents=True, exist_ok=True)  # Ensure dir exists
        with open(output_mapping_file_path, 'w', encoding='utf-8') as f:
            json.dump(knowledge_points_texts, f, ensure_ascii=False, indent=4)
        logging.info(f"Knowledge point mapping saved successfully to {output_mapping_file_path}.")
    except Exception as e:
        logging.error(f"Error saving knowledge point mapping to {output_mapping_file_path}: {e}")
        sys.exit(1)

    logging.info(f"\n--- Embedding and Indexing Pipeline for '{unique_file_dir_name}' Finished Successfully ---")
    sys.exit(0)


def main():
    parser = argparse.ArgumentParser(
        description="Generates BERT embeddings for knowledge points from catalog_with_segments.json "
                    "and builds a FAISS index."
    )
    parser.add_argument("project_id", type=str,
                        help="The ID of the project (e.g., 'p123456789').")
    parser.add_argument("unique_file_dir_name", type=str,
                        help="The unique directory name for the processed file (e.g., 'Essay_dir').")

    args = parser.parse_args()
    run_embedding_generation(args.project_id, args.unique_file_dir_name)


if __name__ == "__main__":
    main()
    logging.info("\nScript execution finished.")
